import React, { useState } from "react";
import "./Feedback.css";

const Feedback = () => {
  const [rating, setRating] = useState("");
  const [description, setDescription] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Feedback Sent Successfully!");
  };

  return (
    <div className="feedback-container">
      <Header />

      <h2 className="title">We Value Your Feedback</h2>

      <form className="feedback-form" onSubmit={handleSubmit}>

        <div className="rating-box">
          <label className="rate-label">Rate your experience ⭐⭐⭐⭐⭐</label>
        </div>

        <div className="options">
          <label><input type="radio" value="Excellent" name="rate" onChange={(e)=>setRating(e.target.value)}/> Excellent</label>
          <label><input type="radio" value="Good" name="rate" onChange={(e)=>setRating(e.target.value)}/> Good</label>
          <label><input type="radio" value="Average" name="rate" onChange={(e)=>setRating(e.target.value)}/> Average</label>
          <label><input type="radio" value="Poor" name="rate" onChange={(e)=>setRating(e.target.value)}/> Poor</label>
        </div>

        <h3 className="desc-title">Description:</h3>

        <textarea
          className="desc-input"
          placeholder="Please share your thoughts about our LifeFit platform. Your feedback helps us improve our services and provide a better experience."
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />

        <button type="submit" className="send-btn">Send Feedback</button>
      </form>

      <Footer />

    </div>
  );
};

export default Feedback;
