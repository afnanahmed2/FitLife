import React from 'react'

function EditProfile() {
  return (
    <div>
      
    </div>
  )
}

export default EditProfile
