import React from 'react'

function UpdateClass() {
  return (
    <div>
      
    </div>
  )
}

export default UpdateClass
