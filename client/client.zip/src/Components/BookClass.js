import React from 'react'

function BookClass() {
  return (
    <div>
      
    </div>
  )
}

export default BookClass
