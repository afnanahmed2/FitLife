import React from "react";
import "./styles.css";
//import { Link } from "react-router-dom";
import { FaIdCard } from "react-icons/fa";


const MemberShip = () => {
  const plans = [
    { title: "VIP", coach: "Coach name", price: "price", time: "Time" },
    { title: "Basic", coach: "Coach name", price: "price", time: "Time" },
    { title: "Student", coach: "Coach name", price: "price", time: "Time" },
    { title: "Standard", coach: "Coach name", price: "price", time: "Time" },
  ];

  return (
    <div className="membership-page">
      <div className="membership-header">
        <FaIdCard className="icon" />
        <h2>Membership</h2>
      </div>

      <h3 className="membership-title">Choose Your Membership Plan</h3>

      <div className="membership-grid">
        {plans.map((plan, index) => (
          <div className="membership-card" key={index}>
            <div className="membership-img"></div>

            <div className="membership-info">
              <h4>{plan.title}</h4>
              <p>{plan.coach}</p>
              <p>{plan.price}</p>
              <p>{plan.time}</p>
            </div>

            <button className="choose-btn">Choose</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default MemberShip;
