import React from 'react'

function CaloriesCalculater() {
  return (
    <div>
      
    </div>
  )
}

export default CaloriesCalculater

