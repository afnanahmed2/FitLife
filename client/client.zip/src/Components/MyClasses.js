import React from "react";
import "./styles.css";


const MyClasses = () => {
  return (
    <div className="classes-container">

      <div className="header">
        <img
          src="/gym-logo.png"
          alt="gym"
          className="gym-icon"
        />
        <h2>My Classes</h2>
      </div>

      <div className="class-card">
        <div className="class-image"></div>

        <div className="class-info">
          <p><strong>Class name</strong></p>
          <p>Coach name</p>
        </div>

        <div className="class-details">
          <p><strong>price</strong></p>
          <p>Time</p>
        </div>
      </div>
    </div>
  );
};

export default MyClasses;
