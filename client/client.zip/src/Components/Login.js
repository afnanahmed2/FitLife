import {
  Container,
  Row,
  Col,
} from "reactstrap";
import React from "react";
import { Link } from "react-router-dom";
import "./styles.css";
import logo from "../images/logo.png";
import { useEffect,useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { login } from "../Features/UserSlice";
import { useNavigate } from "react-router-dom";
import { use } from "react";

const Login = () => {
  const navigate = useNavigate(); //declares a constant variable named navigate and assigns it the value returned by the useNavigate() hook
  const {user, msg, status, isLogin} = useSelector(state => state.users)
  useEffect(()=>{
    if(isLogin)
      navigate("/Home")
    else
      navigate("/login")
  }, [isLogin]);

  //Retrieve the current value of the state and assign it to a variable.
  //Create the state variables  
 
  const [email, setemail] = useState("");
  const [password, setpassword] = useState("");  
  const dispatch = useDispatch(); //every time we want to call an action, make an action happen
  
  // Handle form submission
  const loginHandler = () => {
    const userData = {email,password}
    dispatch (login(userData))
  };
  

  return (
    <Container fluid>
      <Row>
        <Col lg="6">
    <form className="div-form">   
    <div className="login-page">
 
      <div className="curve-section">
        <img src={logo} alt="FitLife Logo" className="logo-image" />
      </div>

      <div className="login-card">
        <div className="input-box">
          <input 
          type="text" 
          className="form-control"
          id="email"
          placeholder="Enter your email"
          onChange ={(e) => setemail(e.target.value)}
           />
        </div>

        <div className="input-box">
          <input 
          type="password"
          className="form-control"
          id="password"
          placeholder="Enter your password" 
          onChange ={(e) => setpassword(e.target.value)}
          />
        </div>
        <button type='button' onClick={loginHandler} className="login-btn">
          LOGIN
         </button>
       
        <p className="register-text">
          Don’t have an account? <Link to="/register">Register here</Link>
        </p>
      </div>

    </div>
    </form> 
     </Col>
         </Row>
      <Row>
        <div>
          <p></p>
          <h3>Server Response: {msg}</h3>
          
        </div>
      </Row>
    
    </Container>
  );
}

export default Login;
